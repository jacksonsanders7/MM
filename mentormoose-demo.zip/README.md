# MentorMoose Demo

This is a small front-end only demo of a Tinder-style mentor/mentee swipe UI.

Files:
- index.html
- styles.css
- app.js

To view locally: open `index.html` in your browser.
To host: push this folder to a GitHub repository and enable GitHub Pages (branch `main`, root), or upload to any static host.

Included screenshot: `IMG_0270.png` (from the original conversation).
